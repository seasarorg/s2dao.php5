<?php

/**
 * @author nowel
 */
interface SqlCommand {
    public function execute($args);
}

?>
