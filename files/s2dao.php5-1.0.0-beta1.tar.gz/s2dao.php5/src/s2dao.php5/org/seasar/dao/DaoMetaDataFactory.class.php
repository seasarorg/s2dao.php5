<?php

/**
 * @author nowel
 */
interface DaoMetaDataFactory {
    public function getDaoMetaData($daoClass);
}
?>
