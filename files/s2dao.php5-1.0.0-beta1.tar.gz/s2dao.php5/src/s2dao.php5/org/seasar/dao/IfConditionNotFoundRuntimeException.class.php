<?php

/**
 * @author nowel
 */
class IfConditionNotFoundRuntimeException extends S2RuntimeException {
    
    public function __construct() {
        parent::__construct("EDAO0004");
    }
}
?>
