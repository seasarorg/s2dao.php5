<?php

/**
 * @author nowel
 */
interface IdentifierGenerator {

    public function isSelfGenerate();
    //public function setIdentifier($bean, $ds);
}
?>
