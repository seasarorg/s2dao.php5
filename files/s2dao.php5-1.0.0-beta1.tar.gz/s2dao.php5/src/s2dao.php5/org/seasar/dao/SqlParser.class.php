<?php

/**
 * @author nowel
 */
interface SqlParser {
    public function parse();
}
?>
