<?php

/**
 * @author nowel
 */
class BasicResultSetFactory implements ResultSetFactory {
	
	//public static final ResultSetFactory INSTANCE = new BasicResultSetFactory();

	public function createResultSet($ps) {
		//return PreparedStatementUtil::executeQuery($ps);
        //DataSourceUtil::getConnection($this->dataSource_);
	}

}
?>
