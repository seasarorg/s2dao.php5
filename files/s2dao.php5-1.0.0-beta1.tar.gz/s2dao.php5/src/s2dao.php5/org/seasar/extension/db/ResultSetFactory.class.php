<?php

/**
 * @author nowel
 */
interface ResultSetFactory {
	public function createResultSet($ps);
}
?>
