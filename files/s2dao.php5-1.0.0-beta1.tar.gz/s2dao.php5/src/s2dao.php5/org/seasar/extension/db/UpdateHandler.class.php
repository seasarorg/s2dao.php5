<?php

/**
 * @author Yusuke Hata
 */
interface UpdateHandler {

    /** @throws SQLRuntimeException */
	//public function execute($args, $argTypes);
}
?>
