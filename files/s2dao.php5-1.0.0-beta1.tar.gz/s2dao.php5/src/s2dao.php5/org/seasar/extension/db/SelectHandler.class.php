<?php

/**
 * @author nowel
 */
interface SelectHandler {
    public function execute($element, $args = null, $argTypes = null);
}
?>
